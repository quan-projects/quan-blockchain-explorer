var api = 'http://54.190.59.240:8314';
var blockTargetInterval = 240;
var coinUnits = 100000000;
var symbol = 'NBR';
var refreshDelay = 30000;
// pools stats by MainCoins
var networkStat = {
    "nbr": [
		["nbr.altpools.com", "http://nbr.altpools.com/api"],
		["nbr.4miner.me", "http://us-nbr.4miner.me:8118"],
		["nbr.breakingblock.com", "http://nbr.breakingblock.com:8117"],
        ["nbr.selvahost.com.br", "http://nb.selvahost.com.br:8999"],
        ["nbr.ciapool.com", "http://nbr.ciapool.com:8117"],
        ["niobiopool.com.br", "http://niobiopool.com.br:8119"],
        ["stminerpool.com.br", "http://stminerpool.com.br:8117"],
        ["nbr-pool.ddns.net", "http://nbr-pool.ddns.net:8117"],
		["nbr.qrdpool.net", "http://nbr.qrdpool.net:8117"],
		["niobio.luckypool.org", "https://niobio.luckypool.org/api/"],
		["nbr2.4miner.me", "http://api-cryptonote3.4miner.me:8118"],
		//["niobio-pool.com", "http://niobio-pool.com:8117"],
		["perfectpool.hopto.org", "http://perfectpool.hopto.org:8117"],
		["nbr.minerpool.site", "http://api.minerpool.site:8118"],
		["nbr6.me", "http://nbr6.me:8117"],
		["cryptoknight.cc/niobio", "http://94.130.207.37:40001"],
		["nbrpool.partyvibe.com", "http://nbrpool.partyvibe.com:8117"],
		//["nbr.moedasdigitais.nl", "http://nbrpool.partyvibe.com:8117"],
		
		
						
    ]
};

var networkStat2 = {
    "NBR": [
		["nbr.4miner.me", "http://us-nbr.4miner.me:8118"]
		]
};
